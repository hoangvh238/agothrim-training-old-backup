package Bai2;

public class Validation extends Exception{
    public Validation(String message) {
        super(message);
    }
}
